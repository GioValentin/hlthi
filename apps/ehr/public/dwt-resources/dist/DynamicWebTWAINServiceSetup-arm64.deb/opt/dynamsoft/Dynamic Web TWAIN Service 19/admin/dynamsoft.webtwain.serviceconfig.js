/*! 20250722
* Dynamsoft WebTWAIN Admin Console
* Product: Dynamsoft Web Twain
* Web Site: http://www.dynamsoft.com
*
* Copyright 2025, Dynamsoft Corporation 
* Author: Dynamsoft Support Team
* Version: 1.06
*/
var maxTry = 10000, tryNum = 0, buttonName = '', bErr = false,
  localhost = '127.0.0.1', lib = Dynamsoft.Lib,
  oldHost = '', oldPort = -1, oldSSLPort = -1,
  oldEnablemDNSService = false, oldAlias = '', oldTags = '',
  bNeedReboot = true,
  bindDomainUrl = "https://www.dynamsoft.com/customer/account/certificate?ip=",
  ifEnableWebset,
  clientId = lib.guid();

if (location.host != '127.0.0.1:18625') {
  location.href = 'http://127.0.0.1:18625/';
}


var tabs = document.querySelectorAll('.tab');
var sections = document.querySelectorAll('.form-section');
var radioLocal = document.getElementById('radLocal');
var radioExternal = document.getElementById('radExternal');

function activateTab(targetId) {
	sections.forEach(function(section){
	  section.classList.toggle('active', section.id === targetId);
	});


	tabs.forEach(function(tab) {
	  tab.classList.toggle('active', tab.dataset.target === targetId);
	});


	if (targetId === 'local') {
	  radioLocal.checked = true;
	} else {
	  radioExternal.checked = true;
	}
}
activateTab('local');

tabs.forEach(function(tab) {
tab.addEventListener('click', function() {
  var targetId = tab.dataset.target;
  activateTab(targetId);
});
});

radioLocal.addEventListener('change', function() {
if (radioLocal.checked) {
  activateTab('local');
}
});

radioExternal.addEventListener('change', function() {
if (radioExternal.checked) {
  activateTab('external');
}
});

var checkbox = document.getElementById('enableExternal');
var externalFields = document.getElementById('externalFields');

checkbox.addEventListener('change', function(evt) {
	refreshExternalTab();
	if (!!evt.target.checked) {
		lib.get('ifAddToFirewall').checked = true;
	}
});

function refreshExternalTab(){
	var selHost = lib.get('selectHost');
	var chkIfAddToFirewall = lib.get('ifAddToFirewall');
	var chkIfEnabledBonjour = lib.get('ifEnabledBonjour');
	var btnBindDomain = lib.get('btnBindDomain');
	var domailSSLCert = lib.get('domailSSLCert');

	if (checkbox.checked) {
	  externalFields.classList.remove('disabled');
	  selHost.disabled = false;
	  chkIfAddToFirewall.checked = (Dynamsoft.Lib.LS.item("DS_ServiceConfig_firewall") == "true");
	  chkIfAddToFirewall.disabled = false;
	  chkIfEnabledBonjour.disabled = false;
	  btnBindDomain.disabled = false;
	  btnBindDomain.classList.remove('disabled');
	  domailSSLCert.disabled = false;
	} else {
	  externalFields.classList.add('disabled');
	  selHost.disabled = true;
	  selHost.selectedIndex = 0;
	  lib.get('host').value = selHost.value;
	  chkIfAddToFirewall.checked = false;
	  chkIfAddToFirewall.disabled = true;
	  chkIfEnabledBonjour.checked = false;
	  chkIfEnabledBonjour.disabled = true;
	  btnBindDomain.disabled = true;
	  btnBindDomain.classList.add('disabled');
	  domailSSLCert.disabled = true;
	  refreshBonjourContent();
	}
}

function setLogLevel(newLevel) {

  if (dwtVers && dwtVers.length > 0) {
    var newHost, dwtNewPort, dwtNewSSLPort;

    newHost = lib.get('host').value;
    if (newHost == '')
      newHost = location.hostname;

    dwtNewPort = lib.get('port').innerText;

    lib.each(dwtVers, function (dwtVersion) {
      var url = ['http://', newHost, ':', dwtNewPort, '/fa/LogLevel?t=', Date.now].join(''),
        _obj = {
          "id": clientId,
          "method": "LogLevel",
          "module": "dwt",
          "parameter": [newLevel],
          "version": dwtVersion
        };

      lib.fetch(url, {
        method: 'post',
        dataType: "json",
        body: lib.stringify(_obj)
      });
    })
  }
}


function ifNewDWTPortOK() {

  var newHost, dwtNewPort, dwtNewSSLPort;

  newHost = lib.get('host').value;
  if (newHost == '')
    newHost = location.hostname;

  dwtNewPort = lib.get('port').innerText;
  dwtNewSSLPort = lib.get('sslPort').innerText;

  if (dwtNewPort == dwtNewSSLPort || dwtNewPort <= 0 || dwtNewSSLPort <= 0) {
    return lib.Promise.resolve(false);
  }

  if (newHost == oldHost) {
    if (parseInt(dwtNewPort) == parseInt(oldPort)) {
      dwtNewPort = -1;
    }
    if (parseInt(dwtNewSSLPort) == parseInt(oldSSLPort)) {
      dwtNewSSLPort = -1;
    }
  } else {
    if (newHost == '127.0.0.1' && oldHost != '127.0.0.1') {
      if (parseInt(dwtNewPort) == parseInt(oldPort)) {
        dwtNewPort = -1;
      }
      if (parseInt(dwtNewSSLPort) == parseInt(oldSSLPort)) {
        dwtNewSSLPort = -1;
      }

      if (dwtNewPort == -1 && dwtNewSSLPort == -1) {
        // only change IP to '127.0.0.1'
        return lib.Promise.resolve(true);
      }
    }

  }

  var cmd = {
    "id": clientId,
    "method": "CheckDWTPort",
    "parameter": [newHost, dwtNewPort, dwtNewSSLPort, 0, 0],
    "version": dcpVersion
  };
  lib.openMsg(); lib.showMsg(-1, '', 'Checking ports...');

  return sendMsg(localhost, cmd)
    .then(function (_) {
      lib.closeMsg();
      bErr = false;
      if (_ && lib.isArray(_.result)) {
        if (_.result[0]) {
          showInfo('Successfully.', 1000);
          return true;
        }
        var err1 = 'The port is already in use.';
        showError(err1);
      }

      return false;
    }, function (err) {
      showError(err);
      lib.closeMsg();
      return false;
    });
}

function getIfEnableWebSetup() {
  var cmd = {
    "id": clientId,
    "method": "GetEnableWebSetup",
    "parameter": [],
    "version": dcpVersion
  };
  lib.openMsg(); lib.showMsg(-1, '', 'Loading...');

  return sendMsg(localhost, cmd)
    .then(function (_) {

      lib.closeMsg();

      ifEnableWebset = _.result[0];
	  if(!ifEnableWebset) {
		lib.get('update-Local').disabled = true;
		lib.get('update-External').disabled = true; 
		lib.get('update-Local').classList.add('disabled');
		lib.get('update-External').classList.add('disabled');
		
		lib.get('selectHost').disabled = true;
		lib.get('sslCert').disabled = true;
		lib.get('enableExternal').disabled = true;
		lib.get('ifAddToFirewall').disabled = true;
		
		lib.get('btnBindDomain').disabled = true;
		lib.get('btnBindDomain').classList.add('disabled');
		lib.get('domailSSLCert').disabled = true;
		lib.get('ifEnabledBonjour').disabled = true;
		lib.get('bonjourAlias').disabled = true;
		lib.get('bonjourTag').disabled = true;
		lib.get('aChangeLob').style.display = "none";
		
		var warningDiv = document.querySelector('.ds-warning-div');

		if (warningDiv) {
			warningDiv.style.display = 'block';
		}
	  }
	  

      bErr = false;
	  
      refreshLogLevel();
      initBonjour();
      initSelectHost();
    }, function () {
      checkReboot();
    });
}

function getInfo() {
  var cmd = {
    "id": clientId,
    "method": "GetServerInfo",
    "parameter": [],
    "version": dcpVersion
  };
  lib.openMsg(); lib.showMsg(-1, '', 'Loading...');

  return sendMsg(localhost, cmd)
    .then(function (_) {

      lib.closeMsg();

      var valHost = '127.0.0.1';
      if(_.Host != '*' && _.Host != '') {
        valHost = _.Host;
      }

      lib.get('host').value = valHost;
      lib.get('port').innerText = _.dwt.port;
      lib.get('sslPort').innerText = _.dwt.sslPort;
	  lib.get('exter-port').innerText = _.dwt.port;
      lib.get('exter-sslPort').innerText = _.dwt.sslPort;
	  
	  if(valHost != "127.0.0.1") {
          if (ifEnableWebset) {
            lib.get('enableExternal').disabled = false;
            lib.get('enableExternal').checked = true;
          }
		  refreshExternalTab();
	  } else {
		 lib.get('enableExternal').checked = false; 
		 lib.get('ifAddToFirewall').checked = false; 	 
	  }

      oldHost = valHost;
      oldPort = _.dwt.port;
      oldSSLPort = _.dwt.sslPort;

      var selHost = lib.get('selectHost');
      selHost.value = valHost;

      buttonName = ''; bErr = false;
    }, function () {
      checkReboot();
    });
}

function innerSetServerInfo() {
  var cmd = {
    "id": clientId,
    "method": "SetServerInfo",
    "version": dcpVersion
  }, dwtNewPort, dwtNewSSLPort;

  var newHost = lib.get('host').value;
  if (newHost == '')
    newHost = location.hostname;

  buttonName = 'UPDATE'; bErr = false;
  lib.openMsg(); lib.showMsg(-1, '', 'Rebooting...');
  
  if(oldHost == newHost)
	  return lib.Promise.resolve(true);

  dwtNewPort = lib.get('port').innerText;
  dwtNewSSLPort = lib.get('sslPort').innerText;

  cmd.parameter = [newHost, 18625, 18626, dwtNewPort, dwtNewSSLPort];

  return sendMsg(localhost, cmd);
   
}

function updateFirewall() {
  var cmd2 = {}, strFirewallEnabled = "false";
  var bAddFirewall = lib.get('ifAddToFirewall').checked;
  if (bAddFirewall) {
    cmd2 = {
      "id": clientId,
      "method": "AddFirewall",
      "parameter": [1],
      "version": dcpVersion
    };
	strFirewallEnabled = "true";
  } else {
	cmd2 = {
      "id": clientId,
      "method": "DeleteFirewall",
      "parameter": [1],
      "version": dcpVersion
    };
  }
  return sendMsg(localhost, cmd2).then(function (_) {
	Dynamsoft.Lib.LS.item("DS_ServiceConfig_firewall", strFirewallEnabled);
  });
}

function innerSetMDNSService() {

  var cmd = {
    "id": clientId,
    "method": "SetmDNSService",
    "version": ddmVersion,
    "cmdId": lib.guid()
  };

  var enablemDNSService = false,
    accessMode = 0,
    alias = '',
    tags = '',
    bAccessFile = 0,
    bAccessScanner = 1,
    bAccessCamera = 0,
    bChangePasswd = 0,
    strPasswd = '';

  buttonName = 'UPDATE'; bErr = false;
  lib.openMsg(); lib.showMsg(-1, '', 'Rebooting...');
  
  if (lib.get('ifEnabledBonjour').checked) {
    enablemDNSService = true;
	
    alias = lib.get('bonjourAlias').value;
    tags = lib.get('bonjourTag').value;
	
	// write to bonjour Alias cache
	Dynamsoft.Lib.LS.item('DS_ServiceConfig_Alias', alias);
	// write to bonjour Tag cache
	Dynamsoft.Lib.LS.item('DS_ServiceConfig_BonjourTag', tags);
	
	if(enablemDNSService == oldEnablemDNSService && oldAlias == alias && oldTags == tags){
		bNeedReboot = false;
		return lib.Promise.resolve(true);
	}
  } else {
	if(enablemDNSService == oldEnablemDNSService){
		bNeedReboot = false;
		return lib.Promise.resolve(true);
	}
  }
  
  // [true, "pc", "r&d1", false, true, false, 0, false, ""]
  cmd.parameter = [enablemDNSService, alias, tags, bAccessFile, bAccessScanner, bAccessCamera, accessMode, bChangePasswd, strPasswd];
  return sendDDM(localhost, cmd);
}

function updateCert() {
  var sslCertZip = lib.get('sslCert').files, promiseFetch;
  if (sslCertZip.length > 0) {
    var aryBuffer = sslCertZip[0];

    var url = ['http://127.0.0.1:18625/dcp/', dcpVersion, '/LoadZipFromBytes?type=4',
      '&dsver=', dcpVersion,
      '&ts=', lib.now()].join('');

    promiseFetch = lib.fetch(url, {
      method: 'post',
      dataType: "json",
      body: aryBuffer
    }).then(function (res) {

      if(res&&res.description){
        throw res.description;
      }

      showInfo('The SSL cert updated.');
      return true;
    }, function (err) {
      throw 'The SSL cert update failed.';
    });
  } else {
    promiseFetch = lib.Promise.resolve(true);
  }

  lib.get('sslCert').value = '';
  return promiseFetch;
}

function updateDomainCert() {
  var sslCertZip = lib.get('domailSSLCert').files, promiseFetch;
  if (sslCertZip.length > 0) {
    var aryBuffer = sslCertZip[0];

    var url = ['http://127.0.0.1:18625/dcp/', dcpVersion, '/LoadZipFromBytes?type=4',
      '&dsver=', dcpVersion,
      '&ts=', lib.now()].join('');

    promiseFetch = lib.fetch(url, {
      method: 'post',
      dataType: "json",
      body: aryBuffer
    }).then(function (res) {

      if(res&&res.description){
        throw res.description;
      }

      showInfo('The SSL cert updated.');
      return true;
    }, function (err) {
      throw 'The SSL cert update failed.';
    });
  } else {
    promiseFetch = lib.Promise.resolve(true);
  }

  lib.get('domailSSLCert').value = '';
  return promiseFetch;
}

function onclick_setExternalInfo() {

  clickedUpdateButton = true;
  lib.hide(lib.one('.ds-tips')[0]);

  var dwtNewPort, dwtNewSSLPort;

  dwtNewPort = lib.get('port').innerText;
  dwtNewSSLPort = lib.get('sslPort').innerText;

  if (dwtNewPort == dwtNewSSLPort || dwtNewPort <= 0 || dwtNewSSLPort <= 0) {

    lib.show(lib.one('.ds-tips')[0]);
    lib.one('.ds-tips')[0].className = 'ds-tips ds-error';
    if (dwtNewPort == dwtNewSSLPort)
      lib.get('ds-msg').innerHTML = 'The Port is same as the SSL Port.';
    else if (dwtNewPort <= 0)
      lib.get('ds-msg').innerHTML = 'The Port is invalid.';
    else if (dwtNewSSLPort <= 0)
      lib.get('ds-msg').innerHTML = 'The SSL Port is invalid.';

    return;
  }
  
 var _host = lib.get("host").value;
 if (lib.get('ifEnabledBonjour').checked) {
  if(_host.length <= 0){
    lib.show(lib.one('.ds-tips')[0]);
    lib.one('.ds-tips')[0].className = 'ds-tips ds-error';
    lib.get('ds-msg').innerHTML = 'Host is required.';
    return;
  } else {

    if (_host == 0) {
      lib.show(lib.one(".ds-tips")[0]);
      lib.one(".ds-tips")[0].className = "ds-tips ds-error";
      lib.get("ds-msg").innerHTML = "Host is invalid.";
      return;
    } else {
      if(_host == "127.0.0.1"){
        lib.show(lib.one('.ds-tips')[0]);
        lib.one('.ds-tips')[0].className = 'ds-tips ds-error';
        lib.get('ds-msg').innerHTML = 'Host cannot be set to empty.';
        return;
      } else if(_host == "localhost"){
        lib.show(lib.one('.ds-tips')[0]);
        lib.one('.ds-tips')[0].className = 'ds-tips ds-error';
        lib.get('ds-msg').innerHTML = 'Host cannot set to "localhost".';
        return;
      }
    }
  }
  
  
  if(lib.get('bonjourAlias').value.length <= 0){
    lib.show(lib.one('.ds-tips')[0]);
      lib.one('.ds-tips')[0].className = 'ds-tips ds-error';
    lib.get('ds-msg').innerHTML = 'Name is required.';
    return;
  } else if(lib.get('bonjourAlias').value.length > 32){
    lib.show(lib.one('.ds-tips')[0]);
      lib.one('.ds-tips')[0].className = 'ds-tips ds-error';
    lib.get('ds-msg').innerHTML = 'The length of Name exceeds the maximum limit.';
    return;
  }
  
  if(lib.get('bonjourTag').value.length > 128){
    lib.show(lib.one('.ds-tips')[0]);
      lib.one('.ds-tips')[0].className = 'ds-tips ds-error';
    lib.get('ds-msg').innerHTML = 'The length of Tag exceeds the maximum limit.';
    return;
  }
 }

  updateDomainCert().then(function () {
      return innerSetMDNSService();
  }).then(function (bOK) {
    if (bOK) {
      return innerSetServerInfo();
    } else {
	  var err = 'Failed to set Bonjour Service.';
      lib.show(lib.one('.ds-tips')[0]);
      lib.one('.ds-tips')[0].className = 'ds-tips ds-error';
      lib.get('ds-msg').innerHTML = err;
	  throw err;
    }
  }).then(function () {
      return updateFirewall();
  }).then(function (_) {
      return _reboot_inner(localhost);
    }, function (err) {
      lib.forceCloseMsg();
      bErr = true;
      lib.error(err);
      showError(err);
    }).then(function(){
	  oldHost = lib.get('host').value;
	  oldEnablemDNSService = lib.get('ifEnabledBonjour').checked;
	  oldAlias = lib.get('bonjourAlias').value;
	  oldTags = lib.get('bonjourTag').value;
	  bNeedReboot = true;
  });
}

function onclick_setLocalInfo() {

  clickedUpdateButton = true;
  lib.hide(lib.one('.ds-tips')[0]);
  
  var sslCertZip = lib.get('sslCert').files;
  if (sslCertZip.length == 0) {
	lib.show(lib.one('.ds-tips')[0]);
    lib.one('.ds-tips')[0].className = 'ds-tips ds-error';
    lib.get('ds-msg').innerHTML = 'Please select a valid certificate.';
	return;
  }

  updateCert().then(function () {
	  buttonName = 'UPDATE';
      return _reboot_inner(localhost, true);
    }, function (err) {
      lib.forceCloseMsg();
      bErr = true;
      lib.error(err);
      showError(err);
    }).then(function(){
	  bNeedReboot = true;
  });
}


function _reboot_inner(_host, bLocal) {

  var cmd = {
    "id": clientId,
    "method": "Reboot",
    "parameter": [],
    "version": dcpVersion
  };
  tryNum = 0;
  
 /* if(!bLocal){
	  var newHost = lib.get('host').value;
	  if(oldHost == newHost && !bNeedReboot){
		lib.forceCloseMsg();
		lib.show(lib.one('.ds-tips')[0]);
		lib.one('.ds-tips')[0].className = 'ds-tips';
		lib.get('ds-msg').innerHTML = [buttonName, ' ', 'SUCCESSFULLY!'].join('');
		return lib.Promise.resolve(true);
	  }
  }*/
  
  return sendMsg(_host, cmd).then(makesureServiceRestarted, makesureServiceRestarted);
}

function makesureServiceStopped(input) {   
  var retries = 600;
  var retryDelay = 50;
  //console.log(input);
  // eslint-disable-next-line no-undef
  return new Promise(function (resolve, reject) {
      var wrappedFetch = function (attempt) {
          return Dynamsoft.Lib.fetch(input, {
            method: 'post',
            fetchRaw: true,
            timeout: 50
          })
          .then(function (response) {
                if (attempt < retries) {
                  retry(attempt);
              } else {
                  reject(false);
              }
              }
              )
              .catch(function (error) {
                  resolve(true);
              });
      };

      function retry(attempt) {
          setTimeout(function () {
              wrappedFetch(++attempt);
          }, retryDelay);
      }

      return wrappedFetch(0);
  });
}

function makesureServiceRestarted() {
  return makesureServiceStopped(location.href).then(checkReboot, checkReboot);
}


function checkReboot() {
  var cmd2 = {
    "id": clientId,
    "method": "GetServerInfo",
    "parameter": [],
    "version": dcpVersion
  };
  return sendMsg(localhost, cmd2)
    .then(function (_) {
      lib.forceCloseMsg();
      lib.get('port').innerText  = _.dwt.port;
      lib.get('sslPort').innerText  = _.dwt.sslPort;
      oldPort = _.dwt.port;
      oldSSLPort = _.dwt.sslPort;

      if (buttonName == '') {
        lib.hide(lib.one('.ds-tips')[0]);
      } else {
        lib.show(lib.one('.ds-tips')[0]);
        if (bErr) {
          lib.one('.ds-tips')[0].className = 'ds-tips ds-error';
          lib.get('ds-msg').innerHTML = [buttonName, ' ', 'FAILED!'].join('');
        } else {
          lib.one('.ds-tips')[0].className = 'ds-tips';
          lib.get('ds-msg').innerHTML = [buttonName, ' ', 'SUCCESSFULLY!'].join('');
        }

        setTimeout(function () {
          lib.hide(lib.one('.ds-tips')[0]);
        }, 3000);
      }

    }, function () {
      tryNum++;
      if (tryNum > maxTry) {

        if (buttonName == '') {
          lib.hide(lib.one('.ds-tips')[0]);
        } else {
          lib.show(lib.one('.ds-tips')[0]);
          if (buttonName == 'UPDATE' && !bErr) {
            lib.one('.ds-tips')[0].className = 'ds-tips';
            lib.get('ds-msg').innerHTML = [buttonName, ' ', 'SUCCESSFULLY!'].join('');
          } else {
            lib.one('.ds-tips')[0].className = 'ds-tips ds-error';
            lib.get('ds-msg').innerHTML = [buttonName, ' ', 'FAILED!'].join('');
          }

          setTimeout(function () {
            lib.hide(lib.one('.ds-tips')[0]);
          }, 3000);
        }
        lib.showMsg(-1, '', 'Get Server Info Error.');
        return;
      }
      setTimeout(checkReboot, 300);
    });
}

function refreshLogLevel() {

  var logLevel = lib.get('srcLogLevel').value;
  if (logLevel == "14") {
    lib.get('divLog').innerHTML = 'On';
  }
  else {
    lib.get('srcLogLevel').value = "0";
    lib.get('divLog').innerHTML = 'Off';
  }

}

function switchLogLevel() {
  var logLevel = lib.get('srcLogLevel').value, newLevel;
  if (logLevel == "14") {
    newLevel = 0;
    lib.get('srcLogLevel').value = "0";
  } else {
    newLevel = 14;
    lib.get('srcLogLevel').value = "14";
  }

  setLogLevel(newLevel);
  refreshLogLevel();
}

function initBonjour() {
  var ckbBonjour = lib.get('ifEnabledBonjour');
  ckbBonjour.checked = false;
  ckbBonjour.onclick = refreshBonjourContent;
  getmDNSService();
}

function refreshBonjourContent() {
  lib.log('ifEnabledBonjour changed');
  var ckbBonjour = lib.get('ifEnabledBonjour');

  var els = [];
  els.push(lib.get('bonjourAlias'));
  els.push(lib.get('bonjourTag'));

  if (!!ckbBonjour.checked) {
    lib.each(els, function (v, n) {
      v.disabled = "";
    });
	
    lib.get('bonjourAlias').disabled = false;
    lib.get('bonjourTag').disabled = false;
  } else {
    lib.each(els, function (v, n) {
      v.disabled = "disabled";
    });

    lib.get('allowAccessScanner').checked = "checked";
    lib.get('bonjourAlias').value = "";
    lib.get('bonjourAlias').disabled = true;
    lib.get('bonjourTag').value = "";
    lib.get('bonjourTag').disabled = true;
  }
}


function getmDNSService() {

  var cmd = {
    "id": clientId,
    "cmdId": lib.guid(),
    "method": "GetmDNSService",
    "parameter": [],
    "version": ddmVersion
  };
  lib.openMsg(); lib.showMsg(-1, '', 'Loading...');

  return sendDDM(localhost, cmd)
    .then(function (_) {

      lib.closeMsg();
	  
      var accessMode = 0;
        //alias = '',
        //tags = '';
        //bAccessFile = 0,
        //bAccessScanner = 0,
        //bAccessCamera = 0;

      // [true,0,"pc","r&d1",0,0,0]
      var result = dm_parseResultDefault(_);
      if (result && lib.isArray(result) && result.length > 4) {
        oldEnablemDNSService = result[0];
        accessMode = result[1];
        oldAlias = result[2];
        oldTags = result[3];
        //bAccessFile = result[4];
        //bAccessScanner = result[5];
        //bAccessCamera = result[6];

        lib.get('bonjourAlias').value = oldAlias;
        if (oldEnablemDNSService) {
          lib.get('ifEnabledBonjour').checked = "checked";
          lib.get('bonjourTag').value = oldTags;
		  
          //lib.get('allowAccessFile').checked = bAccessFile ? "checked" : false;
          //lib.get('allowAccessScanner').checked = bAccessScanner? "checked" : false;
	
        } else {
          lib.get('ifEnabledBonjour').checked = false;
          lib.get('bonjourTag').value = '';
          //lib.get('allowAccessFile').checked = false;
          //lib.get('allowAccessScanner').checked = false;
        }

        refreshBonjourContent();
      }


      bErr = false;

    }, function () {
      lib.closeMsg();
    });
}

function initSelectHost() {

  lib.openMsg(); lib.showMsg(-1, '', 'Get Local IP...');

  return getLocalIP().then(function (ips) {

    lib.closeMsg();

    if(lib.isArray(ips)) {

      var selHost = lib.get('selectHost');
      selHost.options.length = 0;
      //var newOpt = new Option(localhost, localhost);
	  var newOpt = new Option("", localhost);
      selHost.appendChild(newOpt);

      lib.each(ips, function (ip) {
        var newOpt1 = new Option(ip, ip);
        selHost.appendChild(newOpt1);
      });

      selHost.onchange = function (evt) {
        var host = lib.get('host');
        host.value = evt.target.value;
      }

      bErr = false;
    } else {
      if(ips.description) {
        var err = ips.description;
        lib.error(err);
        bErr = true;
        showError(err);
      }
    }
	
	getInfo();
  }, function (err) {
    lib.closeMsg();
  });

}

function bindDomain() {
    var a = lib.get("host").value;
    window.open(bindDomainUrl + a);
}

function ifEnabledBonjour_onclick() {
	var chkIfEnabledBonjour = lib.get('ifEnabledBonjour'), 
		aliasEl = lib.get('bonjourAlias'),
		tagsEl = lib.get('bonjourTag');

	if (chkIfEnabledBonjour.checked) {
		if(aliasEl.value === '') {
			// read from bonjour Alias cache
			if(lib.LS.item('DS_ServiceConfig_Alias')) {
				aliasEl.value = lib.LS.item('DS_ServiceConfig_Alias');
			}
		}
		
		if(tagsEl.value === '') {
			// read from bonjour Tag cache
			if(lib.LS.item('DS_ServiceConfig_BonjourTag')) {
				tagsEl.value = lib.LS.item('DS_ServiceConfig_BonjourTag');
			}
		}
	}
}

lib.domReady(function () {

  lib.one('.main').style('height', (screen.height - 200) + 'px');
  getIfEnableWebSetup();
  //refreshLogLevel();
  //initBonjour();
  //initSelectHost();
  //getInfo();

  lib.addEventListener(lib.get('update-Local'), 'click', onclick_setLocalInfo);
  lib.addEventListener(lib.get('update-External'), 'click', onclick_setExternalInfo);
  lib.addEventListener(lib.get("btnBindDomain"), "click", bindDomain);
  lib.addEventListener(lib.get("ifEnabledBonjour"), "click", ifEnabledBonjour_onclick);
  
});

